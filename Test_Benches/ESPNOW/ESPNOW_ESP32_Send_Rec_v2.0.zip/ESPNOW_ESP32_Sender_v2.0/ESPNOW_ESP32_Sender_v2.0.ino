#include <esp_now.h>
#include <WiFi.h>

//Receiver MAC address
uint8_t receiverAddress[] = {0x9C,0x9C, 0x1F, 0xD6, 0x87, 0xA0}; 

//Structure to send data with ESPNOW
typedef struct message_struct {
  char a[32];  
} message_struct;

message_struct dataToSend;

esp_now_peer_info_t peerInfo;

//callback for data after it is sent
void OnDataSent(const uint8_t *mac_addr, esp_now_send_status_t status) {
  Serial.print("\r\nLast Packet Send Status:\t");
  Serial.println(status == ESP_NOW_SEND_SUCCESS ? "Delivery Success" : "Delivery Fail");
}

void setup() {
    // Init Serial Monitor
  Serial.begin(115200);
 
  // Set device as a Wi-Fi Station
  WiFi.mode(WIFI_STA);

  // Init ESP-NOW
  if (esp_now_init() != ESP_OK) {
    Serial.println("Error initializing ESP-NOW");
    return;

  }

  // Once ESPNow is successfully Init, we will register for Send CB to
  // get the status of Trasnmitted packet
  esp_now_register_send_cb(OnDataSent);
  
  // Register peer
  memcpy(peerInfo.peer_addr, receiverAddress, 6);
  peerInfo.channel = 0;  
  peerInfo.encrypt = false;
  
  // Add peer        
  if (esp_now_add_peer(&peerInfo) != ESP_OK){
    Serial.println("Failed to add peer");
    return;
  }
}

void inputMessageTranslation(int input){
  switch(input){
  case 1: // Position 1 OR Cut-in Position
    strcpy(dataToSend.a, "00000001");
    break;
  case 2: // Position 2 
    strcpy(dataToSend.a, "00000010");
    break;
  case 3: // Position 3
    strcpy(dataToSend.a, "00000011");
    break;
  case 4: // Position 4
    strcpy(dataToSend.a, "00000100");
    break;
  case 5: // Position 5
    strcpy(dataToSend.a, "00000101");
    break;
  case 6: // MOUNTING Position OR Emergency Stop
    strcpy(dataToSend.a, "00000110");
    break;
  default:
    break;
 }
}

void espNOWSend(){

  // Send message via ESP-NOW
  esp_err_t result = esp_now_send(receiverAddress, (uint8_t *) &dataToSend, sizeof(dataToSend));
   
  if (result == ESP_OK) {
    Serial.println("Sent with success");
  }
  else {
    Serial.println("Error sending the data");
  }
}

void loop() {
  if (Serial.available() > 0) {
    String inputString = Serial.readStringUntil('\n');
    inputString.trim();
    int inputInt = inputString.toInt();  // Convert string to int

    // If inputInt is 0, that could mean the user entered 0 or non-numeric input
    // You might want to check that inputString is not empty and only digits
    if (inputString.length() > 0 && inputInt > 0 && inputInt <= 6) {
      inputMessageTranslation(inputInt);
      espNOWSend();
    } else {
      Serial.println("Invalid input. Enter a number between 1 and 6.");
    }
  }
}
